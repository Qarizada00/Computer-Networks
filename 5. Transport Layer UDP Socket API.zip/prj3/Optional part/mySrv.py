import socket

localIP     = "127.1.1.1"
localPort   = 8888
bufferSize  = 1024
msgFromServer       = ""
bytesToSend         = str.encode(msgFromServer)

 
# Create a datagram socket
UDPServerSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)

# Bind to address and ip
UDPServerSocket.bind((localIP, localPort))
print("UDP Server Is on, What Is your Message")


count= 0 
# Listen for incoming datagrams
while count < 9:

    bytesAddressPair = UDPServerSocket.recvfrom(bufferSize)
    message = bytesAddressPair[0]
    address = bytesAddressPair[1]
    clientMsg = "Message from Client:  {}".format(message)
    clientIP  = "Client IP Address:  {}".format(address)
    print(clientMsg)
    print(clientIP)
    count += 1
   
    # Sending a reply to client
    UDPServerSocket.sendto(bytesToSend, address)