from socket import *
# Create UDP server socket SOCK_DGRAM for UDP datagram packetS
srvSock = socket(AF_INET, SOCK_DGRAM)
srvPort = 8888
srvHost = '127.1.1.1'  # loopback
# Bind the socket to port 8888 on all available interfaces ''
srvSock.bind((srvHost, srvPort))
print("1900004691 " + str(srvPort))
count = 0
while count < 3:     # run the server to answer 3 queries
    count += 1
    rqst, cliAddr = srvSock.recvfrom(2048)
    print('client', cliAddr, 'requested: ', rqst.decode())
    # Form the message to be sent
    reply = '\nClient ' + cliAddr[0] + ' : ' + \
        str(cliAddr[1]) + ' requested > ' + rqst.decode()
    srvSock.sendto(reply.encode(), cliAddr)
# Close the server socket
srvSock.close()
